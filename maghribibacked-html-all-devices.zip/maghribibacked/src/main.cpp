#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;
static const fs::path ROOT = fs::absolute("workspace").lexically_normal();
static const fs::path PUBLIC = fs::absolute("public").lexically_normal();
static const fs::path HEN = fs::absolute("hen").lexically_normal();
static const fs::path SOURCE = fs::absolute("ps3-source").lexically_normal();

std::string decode(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '%' && i + 2 < s.size()) {
            try {
                out += static_cast<char>(std::stoi(s.substr(i + 1, 2), nullptr, 16));
                i += 2;
            } catch (...) { out += s[i]; }
        } else if (s[i] == '+') out += ' ';
        else out += s[i];
    }
    return out;
}
std::string jsonEscape(const std::string& s) {
    std::string o;
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default: if (c >= 32) o += static_cast<char>(c);
        }
    }
    return o;
}
std::map<std::string,std::string> parseForm(const std::string& body) {
    std::map<std::string,std::string> m;
    std::stringstream ss(body); std::string pair;
    while (std::getline(ss, pair, '&')) {
        auto p = pair.find('=');
        if (p != std::string::npos) m[decode(pair.substr(0,p))] = decode(pair.substr(p+1));
    }
    return m;
}
bool safePath(const std::string& rel, fs::path& out) {
    fs::path p = (ROOT / fs::path(rel)).lexically_normal();
    auto r = ROOT.begin(), q = p.begin();
    for (; r != ROOT.end(); ++r, ++q) if (q == p.end() || *r != *q) return false;
    out = p;
    return true;
}
bool safeSourcePath(const std::string& rel, fs::path& out) {
    fs::path p = (SOURCE / fs::path(rel)).lexically_normal();
    auto r = SOURCE.begin(), q = p.begin();
    for (; r != SOURCE.end(); ++r, ++q) if (q == p.end() || *r != *q) return false;
    out = p;
    return true;
}
std::string readFile(const fs::path& p) {
    std::ifstream f(p, std::ios::binary);
    if (!f) return {};
    std::ostringstream ss; ss << f.rdbuf(); return ss.str();
}
void sendResponse(int fd, int code, const std::string& type, const std::string& body) {
    std::string status = code == 200 ? "OK" : code == 400 ? "Bad Request" :
                         code == 403 ? "Forbidden" : code == 404 ? "Not Found" : "500 Internal Server Error";
    std::ostringstream h;
    h << "HTTP/1.1 " << code << " " << status << "\r\n"
      << "Content-Type: " << type << "\r\n"
      << "Content-Length: " << body.size() << "\r\n"
      << "X-Content-Type-Options: nosniff\r\n"
      << "Cache-Control: no-store\r\n"
      << "Connection: close\r\n\r\n";
    std::string packet = h.str() + body;
    size_t sent = 0;
    while (sent < packet.size()) {
        ssize_t n = send(fd, packet.data()+sent, packet.size()-sent, 0);
        if (n <= 0) break;
        sent += static_cast<size_t>(n);
    }
}
std::string field(const std::map<std::string,std::string>& m, const std::string& k) {
    auto i=m.find(k); return i==m.end() ? "" : i->second;
}
void handle(int fd) {
    char buf[65536];
    ssize_t n = recv(fd, buf, sizeof(buf)-1, 0);
    if (n <= 0) { close(fd); return; }
    buf[n] = 0;
    std::string req(buf, static_cast<size_t>(n));
    auto lineEnd = req.find("\r\n");
    if (lineEnd == std::string::npos) { sendResponse(fd,400,"text/plain","Bad request"); close(fd); return; }
    std::istringstream first(req.substr(0,lineEnd));
    std::string method, target, version; first >> method >> target >> version;
    auto headerEnd = req.find("\r\n\r\n");
    std::string body = headerEnd == std::string::npos ? "" : req.substr(headerEnd+4);
    if (headerEnd != std::string::npos) {
        std::string headers = req.substr(lineEnd+2, headerEnd-(lineEnd+2));
        auto cl = headers.find("Content-Length:");
        if (cl != std::string::npos) {
            auto e = headers.find("\r\n", cl);
            size_t len = 0;
            try { len = std::stoul(headers.substr(cl+15, e == std::string::npos ? std::string::npos : e-(cl+15))); } catch (...) {}
            while (body.size() < len && body.size() < 4*1024*1024) {
                n = recv(fd, buf, sizeof(buf), 0);
                if (n <= 0) break;
                body.append(buf, static_cast<size_t>(n));
            }
            if (body.size() > len) body.resize(len);
        }
    }
    auto q = target.find('?');
    std::string path = q == std::string::npos ? target : target.substr(0,q);
    std::string query = q == std::string::npos ? "" : target.substr(q+1);
    auto params = parseForm(query);

    if (method == "GET" && (path == "/" || path == "/index.html")) {
        sendResponse(fd,200,"text/html; charset=utf-8",readFile(PUBLIC/"index.html"));
    } else if (method == "GET" && (path == "/hen" || path == "/hen/")) {
        sendResponse(fd,200,"text/html; charset=utf-8",readFile(HEN/"index.html"));
    } else if (method == "GET" && (path == "/hen/auto" || path == "/hen/auto/")) {
        sendResponse(fd,200,"text/html; charset=utf-8",readFile(HEN/"auto/index.html"));
    } else if (method == "GET" && path == "/hen/ps3hen_v100.js") {
        sendResponse(fd,200,"application/javascript; charset=utf-8",readFile(HEN/"ps3hen_v100.js"));
    } else if (method == "GET" && path == "/hen/auto/ps3hen_v100.js") {
        sendResponse(fd,200,"application/javascript; charset=utf-8",readFile(HEN/"auto/ps3hen_v100.js"));
    } else if (method == "GET" && path == "/hen/offline_local/offline.zip") {
        sendResponse(fd,200,"application/zip",readFile(HEN/"offline_local/offline.zip"));
    } else if (method == "GET" && path == "/hen/offline_local/offline-debug.zip") {
        sendResponse(fd,200,"application/zip",readFile(HEN/"offline_local/offline-debug.zip"));
    } else if (method == "GET" && path == "/api/source/list") {
        std::string rel = field(params,"path"); fs::path dir;
        if (!safeSourcePath(rel,dir)) sendResponse(fd,403,"application/json","{\"error\":\"Path outside PS3 source tree\"}");
        else if (!fs::exists(dir) || !fs::is_directory(dir)) sendResponse(fd,400,"application/json","{\"error\":\"Source folder not found\"}");
        else {
            std::ostringstream out; out << "{\"path\":\"" << jsonEscape(rel) << "\",\"items\":["; bool firstItem=true;
            try { for (const auto& e : fs::directory_iterator(dir)) {
                if (!firstItem) out << ","; firstItem=false;
                out << "{\"name\":\"" << jsonEscape(e.path().filename().string()) << "\",\"dir\":" << (e.is_directory()?"true":"false") << "}";
            }} catch (...) {}
            out << "]}"; sendResponse(fd,200,"application/json",out.str());
        }
    } else if (method == "GET" && path == "/api/source/read") {
        fs::path p;
        if (!safeSourcePath(field(params,"path"),p)) sendResponse(fd,403,"application/json","{\"error\":\"Path outside PS3 source tree\"}");
        else if (!fs::exists(p) || !fs::is_regular_file(p)) sendResponse(fd,404,"application/json","{\"error\":\"Source file not found\"}");
        else { auto data=readFile(p); if (data.size()>1024*1024) sendResponse(fd,400,"application/json","{\"error\":\"Source file exceeds 1 MiB limit\"}");
            else sendResponse(fd,200,"application/json","{\"content\":\""+jsonEscape(data)+"\"}"); }
    } else if (method == "GET" && path == "/api/list") {
        std::string rel = field(params,"path"); fs::path dir;
        if (!safePath(rel,dir)) { sendResponse(fd,403,"application/json","{\"error\":\"Path outside workspace\"}"); }
        else if (!fs::exists(dir) || !fs::is_directory(dir)) { sendResponse(fd,400,"application/json","{\"error\":\"Folder not found\"}"); }
        else {
            std::ostringstream out; out << "{\"path\":\"" << jsonEscape(rel) << "\",\"items\":[";
            bool firstItem=true;
            try {
                for (const auto& e : fs::directory_iterator(dir)) {
                    if (!firstItem) out << ",";
                    firstItem=false;
                    out << "{\"name\":\"" << jsonEscape(e.path().filename().string()) << "\",\"dir\":"
                        << (e.is_directory() ? "true" : "false") << "}";
                }
            } catch (...) {}
            out << "]}"; sendResponse(fd,200,"application/json",out.str());
        }
    } else if (method == "GET" && path == "/api/read") {
        fs::path p;
        if (!safePath(field(params,"path"),p)) sendResponse(fd,403,"application/json","{\"error\":\"Path outside workspace\"}");
        else if (!fs::exists(p) || !fs::is_regular_file(p)) sendResponse(fd,404,"application/json","{\"error\":\"File not found\"}");
        else {
            auto data=readFile(p);
            if (data.size()>1024*1024) sendResponse(fd,400,"application/json","{\"error\":\"File exceeds 1 MiB limit\"}");
            else sendResponse(fd,200,"application/json","{\"content\":\""+jsonEscape(data)+"\"}");
        }
    } else if (method == "POST" && path == "/api/create") {
        auto f=parseForm(body); std::string rel=field(f,"path"), name=field(f,"name");
        if (name.empty() || name.find('/')!=std::string::npos || name.find('\\')!=std::string::npos || name=="." || name=="..")
            sendResponse(fd,400,"application/json","{\"error\":\"Invalid name\"}");
        else {
            fs::path dir,p;
            if (!safePath(rel,dir) || !safePath((fs::path(rel)/name).generic_string(),p))
                sendResponse(fd,403,"application/json","{\"error\":\"Path outside workspace\"}");
            else if (!fs::exists(dir) || !fs::is_directory(dir)) sendResponse(fd,400,"application/json","{\"error\":\"Folder not found\"}");
            else {
                std::ofstream file(p, std::ios::binary);
                if (!file) sendResponse(fd,500,"application/json","{\"error\":\"Could not create file\"}");
                else sendResponse(fd,200,"application/json","{\"ok\":true}");
            }
        }
    } else if (method == "POST" && path == "/api/save") {
        auto f=parseForm(body); fs::path p;
        std::string rel=field(f,"path"), content=field(f,"content");
        if (content.size()>1024*1024) sendResponse(fd,400,"application/json","{\"error\":\"Content exceeds 1 MiB limit\"}");
        else if (!safePath(rel,p)) sendResponse(fd,403,"application/json","{\"error\":\"Path outside workspace\"}");
        else if (!fs::exists(p) || !fs::is_regular_file(p)) sendResponse(fd,404,"application/json","{\"error\":\"File not found\"}");
        else { std::ofstream file(p,std::ios::binary|std::ios::trunc); file<<content; sendResponse(fd,200,"application/json","{\"ok\":true}"); }
    } else if (method == "POST" && path == "/api/mkdir") {
        auto f=parseForm(body); std::string rel=field(f,"path"), name=field(f,"name"); fs::path dir,p;
        if (name.empty() || name.find('/')!=std::string::npos || name.find('\\')!=std::string::npos || name=="." || name=="..")
            sendResponse(fd,400,"application/json","{\"error\":\"Invalid name\"}");
        else if (!safePath(rel,dir) || !safePath((fs::path(rel)/name).generic_string(),p))
            sendResponse(fd,403,"application/json","{\"error\":\"Path outside workspace\"}");
        else if (!fs::create_directory(p)) sendResponse(fd,400,"application/json","{\"error\":\"Could not create folder\"}");
        else sendResponse(fd,200,"application/json","{\"ok\":true}");
    } else {
        sendResponse(fd,404,"text/plain; charset=utf-8","Not found");
    }
    close(fd);
}
int main(int argc, char** argv) {
    int port = 8080;
    if (argc > 1) { try { port = std::stoi(argv[1]); } catch (...) {} }
    std::error_code ec;
    fs::create_directories(ROOT,ec);
    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0) { std::cerr << "socket failed\n"; return 1; }
    int yes=1; setsockopt(server,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));
    sockaddr_in addr{}; addr.sin_family=AF_INET; addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK); addr.sin_port=htons(static_cast<uint16_t>(port));
    if (bind(server,reinterpret_cast<sockaddr*>(&addr),sizeof(addr))<0 || listen(server,16)<0) {
        std::cerr << "Could not bind port " << port << ". Try another port.\n"; close(server); return 1;
    }
    std::cout << "MaghribiBacked listening on http://127.0.0.1:" << port
              << "\nSafe workspace: " << ROOT << "\nPress Ctrl+C to stop.\n";
    while (true) {
        sockaddr_in client{}; socklen_t len=sizeof(client);
        int fd=accept(server,reinterpret_cast<sockaddr*>(&client),&len);
        if (fd>=0) handle(fd);
    }
    close(server); return 0;
}
