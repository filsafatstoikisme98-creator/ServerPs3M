# GitHub Pages edition

This folder is a static version of MaghribiBacked intended for GitHub Pages. It provides a read-only browser for text files in `ps3-source/` and links to the bundled HEN page.

GitHub Pages cannot run the C++ backend or provide writable server-side file management. For the full API/file manager, run the C++ server on a VPS or another host that supports long-running processes.

## Publish
1. Push this repository to GitHub with the default branch named `main`.
2. Open **Settings → Pages** and select **GitHub Actions** as the build/deployment source.
3. Push a commit to `main`, or run the workflow manually under **Actions**.
4. The site URL will appear in the workflow deployment summary and Settings → Pages.

To use a custom domain, configure it under Settings → Pages and add the DNS records GitHub specifies for that repository. Do not assume `maghribi.com` is configured or owned; use only a domain you control.
